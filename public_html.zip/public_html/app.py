from flask import Flask, send_from_directory, abort
import os

# HTML files live in the same folder as this app.py (public_html)
BASE = os.path.dirname(os.path.abspath(__file__))
app = Flask(__name__, static_folder=None)

PAGES = {"scientific", "menu", "discount", "percentage", "bmi", "tip", "age", "date", "area", "length", "mass", "volume", "speed", "time", "data", "temperature", "currency", "cnumeral", "sip", "lumpsum", "investment", "emi", "loan", "gst", "fd", "rd", "si", "ci", "pl"}


@app.route("/")
def home():
    return send_from_directory(BASE, "index.html")


@app.route("/<page>")
@app.route("/<page>.html")
def show(page):
    if page not in PAGES:
        abort(404)
    return send_from_directory(BASE, page + ".html")


@app.errorhandler(404)
def not_found(e):
    return send_from_directory(BASE, "menu.html"), 404


if __name__ == "__main__":
    app.run(debug=True)
